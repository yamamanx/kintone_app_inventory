# kintoneアプリ管理アプリ更新

## Lambda関数

### kintone_app_inventory
* kintoneアプリ管理の情報をkintoneアプリへ格納する

#### 環境変数
* KINTONE_DOMAIN :
* KINTONE_APP : 
* KINTONE_API_KEY :
* KINTONE_ADMIN :
* KINTONE_PASSWORD :

