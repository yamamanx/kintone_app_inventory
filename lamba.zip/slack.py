import requests
import json
import os

class Slack(object):
    def __init__(self):
        self.url = os.environ['SLACK_URL']

    def send_message(self,content,channel):
        payload_dic = {
            "text": content,
            "channel": channel,
        }
        requests.post(self.url, data=json.dumps(payload_dic))
