from datetime import datetime


def gen_ym(ym_text):
    ym = ym_text.replace('今月の電気ご使用量　 【', '').replace('】', '').replace('分', '')
    return datetime.strptime(ym, '%Y年%m月').strftime('%Y%m')


def gen_start_end(ym, interval_text):
    posi = interval_text.find('～')
    start_text = interval_text[:posi]
    end_text = interval_text[posi+1:]
    end_text = end_text[:end_text.find('日')+1]
    year = ym[:4]
    month = int(ym[4:])
    start_month = int(start_text[:start_text.find('月')])
    response = {}
    if month != start_month and month == 1:
        response['start_date'] = datetime.strptime(str(int(year) - 1) + '年' + start_text, '%Y年%m月%d日')
    else:
        response['start_date'] = datetime.strptime(year + '年' + start_text, '%Y年%m月%d日')
    response['end_date'] = datetime.strptime(year + '年' + end_text, '%Y年%m月%d日')

    return response


def gen_ins_date(ym, ins_text):
    return datetime.strptime(ym[:4] + '年' + ins_text, '%Y年%m月%d日')