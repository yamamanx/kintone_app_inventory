import traceback
import logging.config
import os
import util
from selenium import webdriver
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.common.by import By
from selenium.webdriver.support import expected_conditions as ec
from selenium.webdriver.common.desired_capabilities import DesiredCapabilities
from bs4 import BeautifulSoup


KANDEN_URL = 'https://www2.kepco.co.jp/kweb/portal/N08R201.do'
id = '93213378'
password = '33N4MM'

logger = logging.getLogger()
logger.setLevel(logging.DEBUG)

def value_replace(value):
    return value.strip().replace(' ', '').replace('　', '').replace('\n', '').replace('\r', '').replace('\t', '')


def main(event, context):
    try:
        user_agent = (
            "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_11_1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/47.0.2526.111 Safari/537.36"
        )

        dcap = dict(DesiredCapabilities.PHANTOMJS)
        dcap["phantomjs.page.settings.userAgent"] = user_agent
        dcap["marionette"] = True
        dcap["phantomjs.page.settings.javascriptEnabled"] = True

        browser = webdriver.PhantomJS(
              service_log_path=os.path.devnull,
              #executable_path="./phantomjs",
              executable_path="/usr/local/bin/phantomjs",
              service_args=['--ignore-ssl-errors=true', '--load-images=no', '--ssl-protocol=any'],
              desired_capabilities=dcap
            )
        wait = WebDriverWait(browser, 5)

        browser.implicitly_wait(60)
        browser.set_window_size(1124, 850)
        browser.get(KANDEN_URL)

        wait.until(ec.presence_of_all_elements_located)
        logger.debug(browser.title)

        # ログイン
        xpath_user_id = '//*[@id="userId"]'
        xpath_password = '//*[@id="password"]'
        xpath_button_login = '//*[@id="btnLogin"]'

        wait.until(ec.visibility_of_element_located((By.XPATH, xpath_user_id)))
        wait.until(ec.visibility_of_element_located((By.XPATH, xpath_password)))
        wait.until(ec.visibility_of_element_located((By.XPATH, xpath_button_login)))

        user_id = browser.find_element_by_xpath(xpath_user_id)
        password_input = browser.find_element_by_xpath(xpath_password)
        btn_login = browser.find_element_by_xpath(xpath_button_login)

        user_id.send_keys(id)
        password_input.send_keys(password)
        btn_login.click()

        wait.until(ec.presence_of_all_elements_located)
        logger.debug(browser.title)

        # お知らせ閉じる
        oshirase_close_img = browser.find_element_by_xpath('//*[@id="N08TA02F"]/div[2]/a/img')
        if oshirase_close_img.is_displayed():
            oshirase_close_img.click()

        wait.until(ec.presence_of_all_elements_located)
        logger.debug(browser.title)

        # 年月, 検針期間, 検針日取得
        xpath_this_month = '//*[@id="toppage_title"]'
        xpath_use_interval = '//*[@id="toppage_seikyu_kingak"]/table[2]/tbody/tr[1]/td'
        xpath_ins_date = '//*[@id="toppage_seikyu_kingak"]/table[2]/tbody/tr[2]/td'

        wait.until(ec.visibility_of_element_located((By.XPATH, xpath_this_month)))
        wait.until(ec.visibility_of_element_located((By.XPATH, xpath_use_interval)))
        wait.until(ec.visibility_of_element_located((By.XPATH, xpath_ins_date)))

        this_month = util.gen_ym(browser.find_element_by_xpath(xpath_this_month).text)
        use_interval = util.gen_start_end(this_month,
                                          browser.find_element_by_xpath(xpath_use_interval).text)
        ins_date = util.gen_ins_date(this_month,
                                     browser.find_element_by_xpath(xpath_ins_date).text)

        logger.debug(this_month)
        logger.debug(use_interval)
        logger.debug(ins_date)

        # 電気の使用状況ページ
        xpath_amount_btn = '//*[@id="transition"]/div[1]'
        wait.until(ec.visibility_of_element_located((By.XPATH, xpath_amount_btn)))
        browser.execute_script("clickKongetsKenshinKeka('N08T2')")
        wait.until(ec.presence_of_all_elements_located)
        logger.debug(browser.title)

        # 過去のご使用実績
        xpath_linktab3 = '//*[@id="linkTab3"]'
        wait.until(ec.visibility_of_element_located((By.XPATH, xpath_linktab3)))
        browser.execute_script("clickTab(window.e04, 'N08R405', 'N08R414', 'imgTab3', 'tabs-box-tab3')")
        wait.until(ec.presence_of_all_elements_located)
        logger.debug(browser.title)

        # 使用量内訳表示
        xpath_uchiwake = '//*[@id="tgr_siyoryo_uchiwake"]'
        wait.until(ec.visibility_of_element_located((By.XPATH, xpath_uchiwake)))
        browser.execute_script("clickUchiwakeHyojiButon('使用量内訳を表示', '使用量内訳を閉じる')")
        wait.until(ec.presence_of_all_elements_located)
        logger.debug(browser.title)

        # data収集
        data = browser.page_source.encode('utf-8')
        html = BeautifulSoup(data, "html.parser")

        tables = html.findAll('table', class_='table-denki-ryokin-shokai-3')

        th_name = ''
        result = {}
        td_array = []

        for table in tables:
            rows = table.findAll("tr")
            for row in rows:
                for cell in row.findAll(['td', 'th']):
                    if cell.name == 'th':
                        if len(td_array) > 0:
                            result[th_name] = td_array
                            td_array = []
                        th_name = value_replace(cell.get_text())
                    else:
                        td_array.append(value_replace(cell.get_text()))

        if len(td_array) > 0:
            result[th_name] = td_array

        logger.debug(result)

        # 共通項目
        xpath_customer_name = '//*[@id="profile"]/span'
        xpath_contract_name = '//*[@id="keiyakushubetsName"]'

        wait.until(ec.visibility_of_element_located((By.XPATH, xpath_customer_name)))
        wait.until(ec.visibility_of_element_located((By.XPATH, xpath_contract_name)))

        customer_name = browser.find_element_by_xpath(xpath_customer_name).text
        contract_name = browser.find_element_by_xpath(xpath_contract_name).text

        contract_array = contract_name.split('　')
        customer_no = contract_array[0]
        contract_name = contract_array[1]

        logger.debug(customer_name)
        logger.debug(customer_no)
        logger.debug(contract_name)

        browser.close()
        browser.quit()
        return result

    except Exception as e:
        logger.error(traceback.format_exc())
        raise Exception(traceback.format_exc())


def lambda_handler(event, context):
    try:
        event = main(event, context)
        return event
    except Exception as e:
        raise Exception(traceback.format_exc())


if __name__ == '__main__':
    logging.config.fileConfig("logging.conf")
    event = {}
    main(event, None)
